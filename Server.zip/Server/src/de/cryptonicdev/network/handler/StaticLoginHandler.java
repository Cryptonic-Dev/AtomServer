package de.cryptonicdev.network.handler;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.commons.lang3.RandomStringUtils;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.stream.JsonWriter;

import de.cryptonicdev.atommod.network.admin.C06PacketReceiveBan;
import de.cryptonicdev.atommod.network.chat.C02PacketIRC;
import de.cryptonicdev.atommod.network.login.C00PacketLoginStart;
import de.cryptonicdev.atommod.network.login.C01PacketLoginEnd;
import de.cryptonicdev.network.components.User;
import de.cryptonicdev.network.components.UsrPass;
import de.datasecs.hydra.shared.handler.Session;

public class StaticLoginHandler {

	public static File config = new File("users.json");

	public static ArrayList<UsrPass> userpass = new ArrayList<UsrPass>();

	public static ArrayList<User> users = new ArrayList<User>();

	public static void init() {
		try {
			if (!config.exists()) {
				JsonWriter writer = new JsonWriter(new FileWriter(config));
				writer.beginArray();
				writer.endArray();
				writer.flush();
				writer.close();
			}

			JsonArray array = new JsonParser().parse(new FileReader(config)).getAsJsonArray();
			for (JsonElement element : array) {
				JsonObject object = element.getAsJsonObject();
				UsrPass usrPass = new UsrPass(object.get("banned").getAsBoolean(), object.get("username").getAsString(),
						object.get("password").getAsString(), object.get("rank").getAsString());
				userpass.add(usrPass);
			}

			System.out.println("Users: " + userpass.size());

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static UsrPass getUser(String username) {
		for (UsrPass usr : userpass) {
			if (usr.getUsername().equalsIgnoreCase(username)) {
				return usr;
			}
		}
		return null;
	}

	public static User getUserFromSessionID(String sessionID) {
		for (User user : users) {
			if (user.getSessionID().equals(sessionID)) {
				return user;
			}
		}
		return null;
	}
	
	public static User getUserFromSession(Session session) {
		for (User user : users) {
			if (user.getSession() == session) {
				return user;
			}
		}
		return null;
	}
	
	public static void handler(C00PacketLoginStart packet, Session session) {
		System.out.println("Connecter request: U " + packet.getUsername() + " | P " + packet.getPassword());
		UsrPass usr = getUser(packet.getUsername());
		if (usr.isBanned()) {
			session.send(new C06PacketReceiveBan());
		}
		if (usr.getPassword().equals(packet.getPassword())) {
			User user = new User(RandomStringUtils.randomAlphanumeric(128), packet.getUsername(), packet.getPassword(),
					usr.getRank(), session);
			users.add(user);
			C01PacketLoginEnd endPacket = new C01PacketLoginEnd(usr.getRank(), user.getSessionID());
			session.send(endPacket);
			System.out.println("right packet");
		} else {
			C01PacketLoginEnd endPacket = new C01PacketLoginEnd("zero", "ERROR");
			session.send(endPacket);
			System.out.println("false packet");
		}
	}

}