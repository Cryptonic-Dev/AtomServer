package de.cryptonicdev.network.main;

import de.cryptonicdev.network.handler.StaticLoginHandler;
import de.cryptonicdev.network.protocol.PacketProtocol;
import de.datasecs.hydra.server.HydraServer;
import de.datasecs.hydra.server.Server;
import de.datasecs.hydra.shared.handler.Session;
import de.datasecs.hydra.shared.handler.listener.HydraSessionListener;
import io.netty.channel.ChannelOption;

public class NetworkServer {

	public static HydraServer server;

	@SuppressWarnings("boxing")
	public static void main(String[] args) {
		StaticLoginHandler.init();
		server = new Server.Builder("127.0.0.1", 18888, new PacketProtocol()).bossThreads(2).workerThreads(4)
				.option(ChannelOption.TCP_NODELAY, true).option(ChannelOption.SO_KEEPALIVE, true)
				.childOption(ChannelOption.TCP_NODELAY, true).childOption(ChannelOption.SO_KEEPALIVE, true)
				.addListener(new HydraSessionListener() {
					@Override
					public void onConnected(Session session) {
						System.out.println("\nA has Client connected! " + session.getAddress());
					}

					@Override
					public void onDisconnected(Session session) {
						System.out.println("\nA has Client disconnected! " + session.getAddress());
						try {
							StaticLoginHandler.users.remove(StaticLoginHandler.getUserFromSession(session));
						} catch (Exception e) {}
					}
				}).build();

		if (server.isActive()) {
			System.out.println("Server is online!");
			System.out.printf("Socket address: %s%n", server.getLocalAdress());
		}
	}

}
