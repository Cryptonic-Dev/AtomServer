package de.cryptonicdev.network.protocol;

import de.cryptonicdev.atommod.network.chat.C02PacketIRC;
import de.cryptonicdev.atommod.network.chat.C03PacketMessageReceive;
import de.cryptonicdev.atommod.network.login.C00PacketLoginStart;
import de.cryptonicdev.network.components.User;
import de.cryptonicdev.network.handler.StaticLoginHandler;
import de.cryptonicdev.network.main.NetworkServer;
import de.datasecs.hydra.shared.distribution.Distribution;
import de.datasecs.hydra.shared.handler.Session;
import de.datasecs.hydra.shared.protocol.packets.listener.HydraPacketListener;
import de.datasecs.hydra.shared.protocol.packets.listener.PacketHandler;

public class NetworkPacketHandler implements HydraPacketListener {

	public NetworkPacketHandler() {
	}

	@PacketHandler
	public void onLogin(C00PacketLoginStart packet, Session session) {
		StaticLoginHandler.handler(packet, session);
	}

	@PacketHandler
	public void onIRCPacket(C02PacketIRC packet, Session session) {
		User user = StaticLoginHandler.getUserFromSessionID(packet.getSessionID());
		if (user != null && user.getUsername().equals(packet.getUsername())) {
			String message = "";
			message = user.getRank();
			message += "§f" + packet.getMessage();
			NetworkServer.server.send(new C03PacketMessageReceive(message), Distribution.SIMPLE_BROADCAST);
		}
	}
}
