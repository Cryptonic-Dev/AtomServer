package de.cryptonicdev.network.protocol;

import de.cryptonicdev.atommod.network.admin.C05PacketSendBan;
import de.cryptonicdev.atommod.network.admin.C06PacketReceiveBan;
import de.cryptonicdev.atommod.network.chat.C02PacketIRC;
import de.cryptonicdev.atommod.network.login.C00PacketLoginStart;
import de.cryptonicdev.atommod.network.login.C01PacketLoginEnd;
import de.datasecs.hydra.shared.protocol.impl.HydraProtocol;

public class PacketProtocol extends HydraProtocol {

	public PacketProtocol() {
		registerPacket(C00PacketLoginStart.class);
		registerPacket(C01PacketLoginEnd.class);
		registerPacket(C02PacketIRC.class);
		registerPacket(C05PacketSendBan.class);
		registerPacket(C06PacketReceiveBan.class);
		registerListener(new NetworkPacketHandler());
	}
	
}
