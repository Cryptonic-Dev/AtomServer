package de.cryptonicdev.network.components;

public class UsrPass {

	private String username;
	private String password;
	private String rank;
	private boolean banned;

	public UsrPass(boolean banned, String username, String password, String rank) {
		this.banned = banned;
		this.username = username;
		this.password = password;
		this.rank = rank;
	}

	public String getUsername() {
		return username;
	}

	public String getPassword() {
		return password;
	}

	public String getRank() {
		return rank;
	}

	public boolean isBanned() {
		return banned;
	}

}
