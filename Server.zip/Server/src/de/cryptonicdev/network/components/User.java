package de.cryptonicdev.network.components;

import de.datasecs.hydra.shared.handler.Session;

public class User {

	private String sessionID;
	private String username;
	private String password;
	private String rank;
	private Session session;

	public Session getSession() {
		return session;
	}

	public User(String sessionID, String username, String password, String rank, Session session) {
		super();
		this.sessionID = sessionID;
		this.username = username;
		this.password = password;
		this.rank = rank;
		this.session = session;
	}

	public String getSessionID() {
		return sessionID;
	}

	public String getUsername() {
		return username;
	}

	public String getPassword() {
		return password;
	}

	public String getRank() {
		return rank;
	}

}
