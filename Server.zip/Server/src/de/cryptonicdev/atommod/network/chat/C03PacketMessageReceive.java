package de.cryptonicdev.atommod.network.chat;

import de.datasecs.hydra.shared.protocol.packets.Packet;
import de.datasecs.hydra.shared.protocol.packets.PacketId;
import io.netty.buffer.ByteBuf;

@PacketId(3)
public class C03PacketMessageReceive extends Packet {

	private String message;

	public C03PacketMessageReceive(String message) {
		this.message = message;
	}

	public C03PacketMessageReceive() {
	}

	@Override
	public void read(ByteBuf byteBuf) {
		this.message = readString(byteBuf);
	}

	@Override
	public void write(ByteBuf byteBuf) {
		this.writeString(byteBuf, message);
	}

	public String getMessage() {
		return message;
	}

}
