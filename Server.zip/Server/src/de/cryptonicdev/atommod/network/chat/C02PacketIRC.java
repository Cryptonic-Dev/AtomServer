package de.cryptonicdev.atommod.network.chat;

import de.datasecs.hydra.shared.protocol.packets.Packet;
import de.datasecs.hydra.shared.protocol.packets.PacketId;
import io.netty.buffer.ByteBuf;

@PacketId(2)
public class C02PacketIRC extends Packet {

	public C02PacketIRC() {
	}

	private String username;
	private String sessionID;
	private String message;

	public C02PacketIRC(String username, String message, String sessionID) {
		super();
		this.username = username;
		this.message = message;
		this.sessionID = sessionID;
	}

	@Override
	public void read(ByteBuf byteBuf) {
		this.username = readString(byteBuf);
		this.sessionID = readString(byteBuf);
		this.message = readString(byteBuf);
	}

	@Override
	public void write(ByteBuf byteBuf) {
		this.writeString(byteBuf, username);
		this.writeString(byteBuf, sessionID);
		this.writeString(byteBuf, message);
	}

	public String getUsername() {
		return username;
	}

	public String getSessionID() {
		return sessionID;
	}

	public String getMessage() {
		return message;
	}

}
