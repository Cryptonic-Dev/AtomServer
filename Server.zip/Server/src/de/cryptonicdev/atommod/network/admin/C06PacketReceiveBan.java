package de.cryptonicdev.atommod.network.admin;

import de.datasecs.hydra.shared.protocol.packets.Packet;
import de.datasecs.hydra.shared.protocol.packets.PacketId;
import io.netty.buffer.ByteBuf;

@PacketId(6)
public class C06PacketReceiveBan extends Packet {

	public C06PacketReceiveBan() {
	}

	@Override
	public void read(ByteBuf byteBuf) {
	}

	@Override
	public void write(ByteBuf byteBuf) {
	}

}
