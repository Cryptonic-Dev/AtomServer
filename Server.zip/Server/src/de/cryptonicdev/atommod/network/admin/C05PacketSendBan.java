package de.cryptonicdev.atommod.network.admin;

import de.datasecs.hydra.shared.protocol.packets.Packet;
import de.datasecs.hydra.shared.protocol.packets.PacketId;
import io.netty.buffer.ByteBuf;

@PacketId(5)
public class C05PacketSendBan extends Packet {

	private String username;
	private String sessionID;
	private String myUsername;

	public C05PacketSendBan() {
	}

	public C05PacketSendBan(String username, String sessionID, String myUsername) {
		this.username = username;
		this.sessionID = sessionID;
		this.myUsername = myUsername;
	}

	@Override
	public void read(ByteBuf byteBuf) {
		this.username = readString(byteBuf);
		this.sessionID = readString(byteBuf);
		this.myUsername = readString(byteBuf);
	}

	@Override
	public void write(ByteBuf byteBuf) {
		this.writeString(byteBuf, username);
		this.writeString(byteBuf, sessionID);
		this.writeString(byteBuf, myUsername);
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getSessionID() {
		return sessionID;
	}

	public void setSessionID(String sessionID) {
		this.sessionID = sessionID;
	}

	public String getMyUsername() {
		return myUsername;
	}

	public void setMyUsername(String myUsername) {
		this.myUsername = myUsername;
	}

}
