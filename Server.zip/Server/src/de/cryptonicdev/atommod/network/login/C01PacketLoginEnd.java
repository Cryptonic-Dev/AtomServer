package de.cryptonicdev.atommod.network.login;

import de.datasecs.hydra.shared.protocol.packets.Packet;
import de.datasecs.hydra.shared.protocol.packets.PacketId;
import io.netty.buffer.ByteBuf;

@PacketId(1)
public class C01PacketLoginEnd extends Packet {

	private String rank;
	private String sessionID;

	public C01PacketLoginEnd() {
	}

	public C01PacketLoginEnd( String rank, String sessionID) {
		this.rank = rank;
		this.sessionID = sessionID;
	}

	@Override
	public void read(ByteBuf byteBuf) {
		this.sessionID = readString(byteBuf);
		this.rank = readString(byteBuf);
	}

	@Override
	public void write(ByteBuf byteBuf) {
		this.writeString(byteBuf, sessionID);
		this.writeString(byteBuf, rank);
	}

	public String getRank() {
		return rank;
	}

	public String getSessionID() {
		return sessionID;
	}

}
