package de.cryptonicdev.atommod.network.login;

import org.apache.commons.codec.digest.DigestUtils;

import de.datasecs.hydra.shared.protocol.packets.Packet;
import de.datasecs.hydra.shared.protocol.packets.PacketId;
import io.netty.buffer.ByteBuf;

@PacketId(0)
public class C00PacketLoginStart extends Packet {

	public C00PacketLoginStart() {
	}

	public C00PacketLoginStart(String username, String password) {
		this.username = username;
		this.password = password;
	}

	private String username;
	private String password;

	@Override
	public void read(ByteBuf byteBuf) {
		this.username = readString(byteBuf);
		this.password = readString(byteBuf);
	}

	@Override
	public void write(ByteBuf byteBuf) {
		this.writeString(byteBuf, username);
		this.writeString(byteBuf, DigestUtils.sha512Hex(password));
	}

	public String getUsername() {
		return username;
	}

	public String getPassword() {
		return password;
	}

}
